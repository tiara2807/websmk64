<div class="one_quarter first">
    <ul class="nospace">
        <li class="btmspace-15">
            <a href="#"><em class="heading">Pengumuman Hasil Tes Mutasi Masuk Semester Ganjil TP
                    2023_2024 Gel-2</em>
                <img class="borderedbox" src="images/demo/last news/1.png" alt="" /></a>
        </li>
        <li class="btmspace-15">
            <a href="#"><em class="heading">Sidang Hasil Prakerin Jurusan RPL dan Multimedia SMKN 64
                    Jakarta</em>
                <img class="borderedbox" src="images/demo/last news/2.png" alt="" /></a>
        </li>
        <li class="btmspace-15">
            <a href="#"><em class="heading">Pengumuman Mutasi Masuk Peserta Didik SMKN 64 Jakarta
                    Tahun Ajaran 2023/2024 Semester Ganjil TAHAP 2</em>
                <img class="borderedbox" src="images/demo/last news/3.png" alt="" /></a>
        </li>
        <li>
            <a href="#"><em class="heading">Pengumuman Hasil Tes Mutasi Masuk Semester Ganjil TP
                    2023_2024 Gel-1</em>
                <img class="borderedbox" src="images/demo/last news/4.png" alt="" /></a>
        </li>
    </ul>
</div>