<div class="one_quarter sidebar">
    <div class="sdb_holder">
        <h6>SMKN 64</h6>
        <div class="mediacontainer">
            <img src="images/demo/kpsk.jpeg" alt="" />
            <p>
                DEWI PUSPITASARI, S.ST.PAR, M.PAR
                <br />
                - Kepala Sekolah - <br />
                Sebagai lembaga pendidikan, SMKN 64 Jakarta tanggap dengan
                perkembangan teknologi tersebut. Dengan dukungan SDM yang di
                miliki sekolah ini siap…
                <br />
                <a href="https://www.youtube.com/@smkn64jakarta22/youtube.com/smkn64jkt">View More Videos Here</a>
            </p>
        </div>
    </div>
    <div class="sdb_holder">
        <h6>Quick Information</h6>
        <ul class="nospace quickinfo">
            <li class="clear">
                <a href="https://youtu.be/_0ny0EYg4n4?si=Zme2MTMW3plo5hFo"><img src="images/demo/ytl/1.jpg" />SMKN 64 JAKARTA</a>
            </li>
            <li class="clear">
                <a href="https://youtu.be/_0ny0EYg4n4?si=Zme2MTMW3plo5hFo"><img src="images/demo/ytl/2.jpg" />Pelepasan dan
                    penyambutan kepala sekolah</a>
            </li>
        </ul>
    </div>
</div>