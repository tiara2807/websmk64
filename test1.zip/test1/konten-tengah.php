<div class="one_half">
    <h2>Latest photo &amp; Events</h2>
    <ul class="nospace listing">
        <li class="clear">
            <div class="imgl borderedbox">
                <img src="images/demo/last photo/1.jpg" alt="" />
            </div>
            <p class="nospace btmspace-15"></p>
            <h2>
                <b>Pelepasan kepala sekolah dan sambutan kepala sekolah</b>
            </h2>
        </li>
        <li class="clear">
            <div class="imgl borderedbox">
                <img src="images/demo/last photo/2.jpg" alt="" />
            </div>
            <p class="nospace btmspace-15"></p>
            <h2>
                <b>Pemanfaatan Limbah Barang Bekas saat PTM</b>
            </h2>
            <p>
                Membuat wadah dan tempat cuci tangan serta sanitizer saat
                ptm
            </p>
        </li>
        <li class="clear">
            <div class="imgl borderedbox">
                <img src="images/demo/last photo/3.jpg" alt="" />
            </div>
            <p class="nospace btmspace-15"></p>
            <h2>
                <b>Gerakan Literasi </b>
            </h2>
            <p>Kegiatan Literasi SMKN 64 jakarta</p>
        </li>
    </ul>
    <p class="right">
        <a href="#">Click here to view all of the latest news and events
            &raquo;</a>
    </p>
</div>