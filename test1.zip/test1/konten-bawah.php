<div id="instagram" class="group btmspace-30">
    <div class="one_quarter first center">
        <a href="https://www.instagram.com/smkn64jakarta/"><img src="images/demo/ytl/3.jpeg"/><br />
            Follow Us On instagram</a>
    </div>
    <div class="three_quarter bold">
        <p>
            Follow us in instagram to see more information and update
            <a href="https://www.instagram.com/smkn64jakarta/">@smkn64jakarta</a>
        </p>
    </div>
</div>
<div class="group">
    <h2>Quickly Find What You Are Looking For</h2>
    <div class="one_quarter first">
        <ul class="nospace">
            <li><a href="#">BERITA</a></li>
            <li><a href="#">SEKILAS INFO</a></li>
            <li><a href="#">SMKN 64 JAKARTA</a></li>
            <li><a href="#">PPDB JAKARTA 2021</a></li>
            <li><a href="#">FESTIVALP5</a></li>
        </ul>
    </div>
    <div class="one_quarter">
        <ul class="nospace">
            <li><a href="#">PERPUSTAKAAN ONLINE</a></li>
            <li><a href="#">PENGUMUMAN</a></li>
            <li><a href="#">INFORMASI</a></li>
            <li><a href="#">PPDB JAKARTA</a></li>
            <li><a href="#">PPDB SMKN 64 JAKARTA</a></li>
        </ul>
    </div>
</div>